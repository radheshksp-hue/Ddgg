#!/usr/bin/env python3
"""Offline smoke checks for AI APK Builder Pro source archive.

These checks validate packaging/source structure only. They do not compile Android,
execute Gradle, call GitHub/Gemini, or substitute for the Kotlin/JUnit test suite.
"""
from __future__ import annotations
import pathlib
import re
import sys
import xml.etree.ElementTree as ET
import zipfile
import yaml

ROOT = pathlib.Path(__file__).resolve().parents[1]
checks: list[tuple[str, bool, str]] = []

def check(name: str, condition: bool, detail: str = "") -> None:
    checks.append((name, condition, detail))
    print(f"{'PASS' if condition else 'FAIL'}: {name}" + (f" — {detail}" if detail else ""))

required = [
    "settings.gradle.kts", "build.gradle.kts", "gradle.properties", "gradle/wrapper/gradle-wrapper.properties",
    "gradlew", "gradlew.bat", "app/build.gradle.kts", "app/src/main/AndroidManifest.xml",
    "app/src/main/java/com/aipkgbuilder/pro/MainActivity.kt",
    "app/src/main/java/com/aipkgbuilder/pro/BuilderViewModel.kt",
    "app/src/main/java/com/aipkgbuilder/pro/github/GitHubClient.kt",
    "app/src/main/java/com/aipkgbuilder/pro/gemini/GeminiClient.kt",
    "app/src/main/java/com/aipkgbuilder/pro/build/PatchValidator.kt",
    ".github/workflows/build-apk.yml", "README.md", "TEST_REPORT.md",
]
missing = [p for p in required if not (ROOT / p).is_file()]
check("required project files are present", not missing, ", ".join(missing))

workflow_path = ROOT / ".github/workflows/build-apk.yml"
asset_path = ROOT / "app/src/main/assets/templates/build-apk.yml"
check("both project-build workflow and separate builder-service template exist", workflow_path.is_file() and asset_path.is_file())

try:
    workflow = yaml.load(workflow_path.read_text(encoding="utf-8"), Loader=yaml.BaseLoader)
    trigger = workflow.get("on", workflow.get(True, {})) or {}
    check("workflow YAML parses and supports push plus manual dispatch", "push" in trigger and "workflow_dispatch" in trigger)
    check("workflow avoids write permissions for hosted build token", workflow.get("permissions", {}).get("contents") == "read")
    workflow_text = workflow_path.read_text(encoding="utf-8")
    check("workflow has explicit wrapper generation when JAR is absent", "./gradlew wrapper --gradle-version 8.13" in workflow_text)
    check("workflow installs supported SDK packages without obsolete tools package", "cmdline-tools" in workflow_text and "build-tools;$ANDROID_BUILD_TOOLS" in workflow_text and '"tools"' not in workflow_text)
    check("workflow validates module/manifest paths and fails clearly", "app/src/main/AndroidManifest.xml" in workflow_text and "Missing app/build.gradle.kts" in workflow_text)
    check("workflow uploads success APKs and failure diagnostics", "ai-apk-builder-pro-debug-apk" in workflow_text and "ai-apk-builder-pro-build-diagnostics" in workflow_text and "if: always()" in workflow_text)
except Exception as exc:
    check("workflow YAML parses", False, str(exc))

try:
    ET.parse(ROOT / "app/src/main/AndroidManifest.xml")
    check("AndroidManifest.xml is well-formed XML", True)
except Exception as exc:
    check("AndroidManifest.xml is well-formed XML", False, str(exc))

props = (ROOT / "gradle/wrapper/gradle-wrapper.properties").read_text(encoding="utf-8")
check("Gradle distribution URL is pinned to Gradle 8.13", "gradle-8.13-bin.zip" in props)
bootstrap = (ROOT / "gradlew").read_text(encoding="utf-8")
check("bootstrap transparently identifies missing official wrapper JAR", "NOT the official Gradle Wrapper" in bootstrap and not (ROOT / "gradle/wrapper/gradle-wrapper.jar").exists())

for fixture in ["valid-nested-project.zip", "broken-project.zip"]:
    path = ROOT / "fixtures" / fixture
    try:
        with zipfile.ZipFile(path) as archive:
            bad = archive.testzip()
        check(f"fixture archive integrity: {fixture}", bad is None)
    except Exception as exc:
        check(f"fixture archive integrity: {fixture}", False, str(exc))

try:
    with zipfile.ZipFile(ROOT / "fixtures/path-traversal.zip") as archive:
        names = archive.namelist()
    check("ZIP-slip fixture contains traversal test entry", any(name.startswith("../") for name in names))
except Exception as exc:
    check("ZIP-slip fixture exists", False, str(exc))
try:
    with zipfile.ZipFile(ROOT / "fixtures/malformed.zip"):
        pass
    malformed_rejected = False
except zipfile.BadZipFile:
    malformed_rejected = True
check("malformed ZIP fixture is genuinely malformed", malformed_rejected)

# Ensure production source does not ship literal credential-shaped examples/values.
patterns = [re.compile(r"gh[pousr]_[A-Za-z0-9_]{25,}"), re.compile(r"github_pat_[A-Za-z0-9_]{25,}"), re.compile(r"AIza[0-9A-Za-z_-]{30,}")]
leaks = []
for file in ROOT.rglob("*"):
    if not file.is_file() or any(part in {".git", "build"} for part in file.parts):
        continue
    if file.suffix.lower() in {".kt", ".kts", ".yml", ".yaml", ".xml", ".md", ".properties", ".py", ".sh", ".bat"}:
        try: data = file.read_text(encoding="utf-8", errors="ignore")
        except OSError: continue
        if any(pattern.search(data) for pattern in patterns): leaks.append(str(file.relative_to(ROOT)))
check("no token-shaped credentials found in text source", not leaks, ", ".join(leaks))

failed = [name for name, passed, _ in checks if not passed]
print(f"\nSummary: {len(checks) - len(failed)}/{len(checks)} smoke checks passed.")
if failed:
    print("Failed checks: " + ", ".join(failed))
    sys.exit(1)
