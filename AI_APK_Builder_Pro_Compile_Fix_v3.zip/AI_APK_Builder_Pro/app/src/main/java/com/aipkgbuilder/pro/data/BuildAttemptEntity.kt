package com.aipkgbuilder.pro.data

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "build_attempts",
    indices = [Index("projectId"), Index(value = ["releaseTag"], unique = true)]
)
data class BuildAttemptEntity(
    @PrimaryKey val id: String,
    val projectId: String,
    val attemptNumber: Int,
    val releaseTag: String,
    val releaseId: Long? = null,
    val workflowRunId: Long? = null,
    val status: String = "PREPARING",
    val startedAt: Long,
    val completedAt: Long? = null,
    val artifactId: Long? = null,
    val apkPath: String? = null,
    val diagnosticsPath: String? = null,
    val message: String? = null,
    val changedFilesJson: String = "[]"
)
