package com.aipkgbuilder.pro.util

import org.junit.Assert.*
import org.junit.Test

class RedactorTest {
    @Test fun redactsGitHubGeminiAndAuthorizationSecrets() {
        // Construct disposable pattern samples from separate fragments so repository scans do not mistake these tests for real credentials.
        val github = "ghp_" + "12345678901234567890123456789012"
        val google = "AIza" + "123456789012345678901234567890123"
        val source = "Authorization: Bearer $github\napi_key=$google\nx-goog-api-key: secret-key-value"
        val result = Redactor.redact(source)
        assertFalse(result.contains(github))
        assertFalse(result.contains(google))
        assertFalse(result.contains("secret-key-value"))
    }
}
