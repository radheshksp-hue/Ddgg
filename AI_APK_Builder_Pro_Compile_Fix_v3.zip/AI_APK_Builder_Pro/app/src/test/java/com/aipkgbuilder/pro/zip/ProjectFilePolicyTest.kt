package com.aipkgbuilder.pro.zip

import org.junit.Assert.*
import org.junit.Test
import java.io.File
import java.nio.file.Files

class ProjectFilePolicyTest {
    @Test fun excludesBuildCachesLocalSdkAndSigningKeys() {
        val temp = Files.createTempDirectory("file-policy").toFile()
        try {
            val safe = File(temp, "src/main/java/com/example/MainActivity.kt").apply { parentFile.mkdirs(); writeText("fun hello() = Unit") }
            val local = File(temp, "local.properties").apply { writeText("sdk.dir=/private/android/sdk") }
            val key = File(temp, "release-key.jks").apply { writeBytes(byteArrayOf(1, 2, 3)) }
            assertFalse(ProjectFilePolicy.shouldExcludeFile(safe, "src/main/java/com/example/MainActivity.kt"))
            assertTrue(ProjectFilePolicy.shouldExcludeFile(local, "local.properties"))
            assertTrue(ProjectFilePolicy.shouldExcludeFile(key, "release-key.jks"))
            assertTrue(ProjectFilePolicy.shouldSkipDirectory("app/build/intermediates"))
            assertTrue(ProjectFilePolicy.shouldSkipDirectory(".git/objects"))
        } finally { temp.deleteRecursively() }
    }

    @Test fun excludesContentsThatLookLikeSecrets() {
        val temp = Files.createTempDirectory("secret-policy").toFile()
        try {
            val file = File(temp, "app.properties").apply { writeText("api_key=AIzaSyD123456789012345678901") }
            assertTrue(ProjectFilePolicy.shouldExcludeFile(file, "app.properties"))
        } finally { temp.deleteRecursively() }
    }
}
